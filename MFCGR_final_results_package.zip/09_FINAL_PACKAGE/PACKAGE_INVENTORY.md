# Final package file inventory

Selected cohort rows reported by source file: 120
Files copied: 19

## Included
- tables/selected_120_isolates.csv
- tables/methyltransferase_gene_variants_120.csv
- tables/methyltransferase_variant_consequences_standardized.csv
- tables/consequence_independent_validation.csv
- tables/consequence_validation_summary.csv
- tables/cohort_top_variant_validation.csv
- tables/top_variant_fisher_tests.csv
- tables/candidate_annotation_check.csv
- tables/candidate_allele_group_summary.csv
- tables/preliminary_candidate_gene_ranking.csv
- tables/circos_candidate_data.csv
- tables/candidate_gene_sequences.fasta
- tables/candidate_sequence_summary.csv
- tables/MFCGR_results_inventory.md
- figures/CGR_Rv2024c.png
- figures/CGR_Rv2756c.png
- figures/CGR_Rv2761c.png
- figures/CGR_Rv3263.png
- figures/candidate_loci_circular_overview.png

## Missing source files
- None

The package contains preliminary results and explicitly documents remaining validation.