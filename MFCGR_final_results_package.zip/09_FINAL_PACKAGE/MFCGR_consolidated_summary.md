# MFCGR Project — Consolidated Preliminary Results

## Project title
MFCGR: Methylation-aware Fractal Chaos Game Representation for
Characterizing Drug-Resistant *Mycobacterium tuberculosis* Genomes

## Current computational progress
- A selected cohort of 120 isolates was prepared, with 30 isolates in each
  resistance category: Sensitive, MDR, Pre-XDR and XDR.
- Candidate-locus variants were extracted from the filtered VCF files.
- First-pass protein consequence predictions were produced and compared with
  a separate codon-level calculation.
- Two candidate SNV positions were assessed using read-level evidence across
  the cohort.
- Exploratory Fisher exact tests and FDR-adjusted q-values were calculated.
- Four reference-sequence CGR figures and one circular candidate-locus overview
  were generated.

## Candidate findings
The current exploratory analysis found associations between the tested alleles
at Rv2024c and Rv3263 and resistance categories in this cohort. These results
are hypothesis-generating and are not evidence of causation.

Rv2756c is annotated as a type I restriction/modification system DNA methylase
(HsdM). Rv2761c is annotated as the HsdS specificity determinant. Rv2024c is
annotated as a hypothetical protein in the reference annotation examined;
its function should not be assumed to be that of a methyltransferase.

## Important limitations
1. The candidate-gene ranking is preliminary and based on exploratory
   association statistics.
2. Lineage/population structure has not yet been controlled for in the
   association analysis.
3. The independent consequence check reproduced the consequence labels and
   protein positions, but full CDS phase, split-feature and annotation validation
   remains necessary. Matching summary counts alone do not establish correctness.
4. The read-level validation covered two candidate positions, not every variant
   in the cohort. The allele-calling parser and thresholds should be reviewed.
5. The CGR figures use reference CDS sequences, not isolate-specific sequences.
6. The circular overview is a preliminary Circos-style visualization, not a
   complete multi-track Circos analysis.
7. The current Illumina sequencing data do not directly measure DNA methylation.
   A true methylation-aware analysis requires compatible methylation measurements
   or a clearly defined and validated alternative.
8. The reported associations do not demonstrate that the variants cause drug
   resistance or change methylation.

## Recommended remaining work
- Validate gene annotations and variant consequences with a trusted annotation
  workflow that handles strand, CDS phase and split CDS features.
- Verify allele calls and coverage across the cohort.
- Reassess associations with lineage/population structure where possible.
- Verify candidate gene functions using authoritative sources.
- Obtain compatible methylation data or clearly narrow the methylation claims.
- Extend CGR to isolate-specific sequences if appropriate.
- Finalize the gene ranking only after these checks.
- Complete the methods, results, discussion and limitations sections of the report.

## Included files
See the `tables/` and `figures/` folders for the copied results.
